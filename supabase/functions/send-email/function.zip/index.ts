// send-email Edge Function - DUAL TIER (Free Ollama + Pro OpenRouter)
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { encode } from 'https://deno.land/std@0.208.0/encoding/base64.ts'

const corsHeaders = { 
  'Access-Control-Allow-Origin': '*', 
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 
  'Access-Control-Allow-Methods': 'POST, OPTIONS' 
}

// Your Gmail credentials
const SMTP_HOST = 'smtp.gmail.com'
const SMTP_PORT = 587
const SMTP_USER = 'aiwealthanaire@gmail.com'
const SMTP_PASS = 'sraz djcd zskd uzkx'

const FALLBACK_OPENROUTER_KEY = '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'

// Ollama settings
const OLLAMA_URL = Deno.env.get('OLLAMA_URL') || 'http://localhost:11434'
const OLLAMA_MODEL = Deno.env.get('OLLAMA_MODEL') || 'llama3.2'

// Get user config from database
async function getUserConfig(supabase: any, accountId: string) {
  const { data } = await supabase
    .from('user_api_config')
    .select('*')
    .eq('account_id', accountId)
    .single()
  return data
}

// Call Ollama (FREE)
async function callOllama(prompt: string): Promise<string> {
  try {
    const response = await fetch(`${OLLAMA_URL}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: OLLAMA_MODEL, prompt, stream: false })
    })
    const data = await response.json()
    return data.response || data.text || ''
  } catch (error) {
    console.error('Ollama failed:', error)
    return ''
  }
}

// Call OpenRouter (PRO)
async function callOpenRouter(prompt: string, apiKey: string, model: string): Promise<string> {
  try {
    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://aiwealthanaire.com',
        'X-Title': 'GTA 6 Real Estate'
      },
      body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], max_tokens: 500 })
    })
    const data = await response.json()
    return data.choices?.[0]?.message?.content || ''
  } catch (error) {
    console.error('OpenRouter failed:', error)
    return ''
  }
}

// AI Email Generator - supports both Free (Ollama) and Pro (OpenRouter)
async function generateAIEmail(
  property: any, 
  offer: any, 
  emailType: string,
  userConfig: any,
  customPrompt?: string
): Promise<{ subject: string; body: string }> {
  
  const context = `
Property Details:
- Address: ${property.address || 'N/A'}
- City: ${property.city || 'N/A'}, ${property.state || 'N/A'}
- Listing Price: ${(property.listing_price || 0).toLocaleString()}
- Estimated Value: ${(property.estimated_value || 0).toLocaleString()}
- Equity: ${(property.estimated_equity || 0).toLocaleString()} (${property.equity_percent || 0}%)
- Days on Market: ${property.days_on_market || 'N/A'}
- Bedrooms: ${property.bedrooms || 'N/A'}, Bathrooms: ${property.bathrooms || 'N/A'}
- Sq Ft: ${property.sqft || 'N/A'}

Offer Details:
- Offer Price: ${(offer?.offer_price || property.listing_price || 0).toLocaleString()}
- Financing: ${offer?.financing_type || 'Flexible'}
- Closing: ${offer?.closing_days || 21} days
- Down Payment: ${offer?.down_payment_percent || 10}%`

  const typePrompts: Record<string, string> = {
    initial_offer: `Write a professional initial offer email to a listing agent. Be direct, confident, and emphasize: quick closing, as-is condition, pre-approved funds, flexibility on terms. Include specific property details.`,
    follow_up_1: `Write a friendly follow-up email 3 days after initial offer. Express continued interest, remind them offer is still open, ask if they have questions.`,
    follow_up_2: `Write a second follow-up email 7 days later. Acknowledge they may be busy, emphasize flexibility, mention key benefits of working with us.`,
    objection_response: `Address seller concerns professionally. Offer solutions like: price adjustment, different financing terms, closing timeline flexibility, including furnishings.`,
    counter_offer: `Respond to a counter-offer professionally. Accept reasonable terms where possible, propose creative alternatives.`,
    closing: `Write a professional closing email once terms are agreed. Confirm next steps, timeline, request necessary documents.`
  }

  const systemPrompt = `You are a professional real estate investor AI assistant. Write personalized, compelling emails that get responses. 

Rules:
- Keep emails SHORT (150-200 words max)
- Always include property address
- Use specific numbers from the context
- Be confident but not pushy
- Include 1-2 key benefits for the seller
- Always end with a question or call to action
- Never use generic greetings - use the agent's name if known`

  const userPrompt = `${context}

Email Type: ${emailType}
${customPrompt ? `Additional Instructions: ${customPrompt}` : ''}

${typePrompts[emailType] || typePrompts.initial_offer}`

  try {
    // Check user's API config
    const hasApiKey = userConfig?.openrouter_key && userConfig.openrouter_key.trim() !== ''
    const preferredModel = userConfig?.model_preference || 'ollama'
    
    let content = ''
    
    if (hasApiKey) {
      // PRO tier - use OpenRouter
      const apiKey = userConfig.openrouter_key
      const model = preferredModel.includes('claude') ? preferredModel : 'anthropic/claude-3-haiku'
      content = await callOpenRouter(`${systemPrompt}\n\n${userPrompt}`, apiKey, model)
    } else {
      // FREE tier - use Ollama
      content = await callOllama(`${systemPrompt}\n\n${userPrompt}`)
    }
    
    if (content) {
      const lines = content.split('\n').filter(l => l.trim())
      const body = lines.join('\n')
      const subjectMatch = content.match(/Subject:?\s*(.+)/i)
      const subject = subjectMatch ? subjectMatch[1].trim() : TEMPLATES[emailType]?.subject?.replace('{address}', property.address || '') || 'RE: Property Offer'
      return { subject, body }
    }
  } catch (error) {
    console.error('AI email generation failed:', error)
  }
  
  // Fallback to template
  return { 
    subject: TEMPLATES[emailType]?.subject?.replace('{address}', property.address || '') || 'RE: Property Offer',
    body: TEMPLATES[emailType]?.body || 'Please contact us regarding the property.' 
  }
}

// Professional email templates
const TEMPLATES: Record<string, { subject: string; body: string }> = {
  initial_offer: { 
    subject: 'Cash Offer - {address}', 
    body: `Dear {agent_name},

I hope this message finds you well. I'm reaching out regarding {address}.

Our team has reviewed the property and we're prepared to move forward with the following offer:

OFFER DETAILS:
Purchase Price: {offer_price}
Estimated Value: {estimated_value}
Down Payment: {down_payment}%
Closing Timeline: {closing_days} days
Financing: {financing_type}

TERMS:
- Property to be conveyed As-Is
- All inspections for informational purposes only
- Commission protected at standard rate
- Multiple financing pathways available

We're a direct buyer with established lending relationships and can close quickly. Our goal is a smooth, efficient transaction that works for all parties.

Please let me know if you'd like to discuss the terms or schedule a call to answer any questions.

Best regards,
GTA 6 Real Estate
(954) 555-0123

---
This offer is valid for 72 hours.`
  },
  follow_up_1: { 
    subject: 'Following Up - {address}', 
    body: `Hi {agent_name},

I wanted to follow up on our offer for {address}.

Our offer remains open and we're genuinely interested in acquiring this property. I understand you're busy - just wanted to keep this on your radar.

Please let me know if you have any questions or if the seller would like to discuss. We're flexible on terms and want to find a way to make this work.

Best,
GTA 6 Real Estate`
  },
  follow_up_2: { 
    subject: '{address} - Any Updates?', 
    body: `Dear {agent_name},

Checking in again on our offer for {address}, {city}.

I understand the market is active and there may be multiple interested parties. Our offer stands as presented and we're prepared to move quickly.

Key points:
- Pre-approval in place
- Flexible closing timeline (21-45 days)
- As-Is condition - no repairs requested
- Quick decision timeline

If there's additional information we can provide, or if the seller has questions, we're available for a quick call.

Otherwise, we'll plan to follow up again in a few days.

Best regards,
GTA 6 Real Estate`
  },
  follow_up_3: { 
    subject: 'Final Follow Up - {address}', 
    body: `Hi {agent_name},

One last reach out regarding {address}.

Our offer of {offer_price} will remain open for 48 more hours. After that, we'll need to move on to other properties on our radar.

We understand market conditions vary, and if this doesn't work for the seller, we wish you well and hope to work together on future opportunities.

Please let me know either way so we can plan accordingly.

Best,
GTA 6 Real Estate`
  },
  negotiation: { 
    subject: 'Re: Counteroffer - {address}', 
    body: `Dear {agent_name},

Thank you for presenting the seller's counter offer of {counter_price}.

We've reviewed carefully and are prepared to respond at {response_price}.

This represents our best compromise and demonstrates genuine interest in acquiring this property.

Key terms remain the same:
- Closing in {closing_days} days
- As-Is condition
- Commission protected

If this works, we can move forward immediately. Please advise if the seller can accept this or if further discussion is needed.

Best regards,
GTA 6 Real Estate`
  },
  acceptance: { 
    subject: 'Agreement Reached - {address}!', 
    body: `Hi {agent_name},

We are pleased to confirm agreement on {address}!

TERMS ACCEPTED:
- Purchase Price: {agreed_price}
- Closing Date: {closing_date}
- Condition: As-Is
- Financing: {financing_type}

NEXT STEPS:
1. We will wire earnest money within 24 hours
2. Please send contract for review
3. We'll schedule inspection at earliest convenient time

We're excited to close this deal and look forward to working with your team.

Best regards,
GTA 6 Real Estate`
  },
  rejection: {
    subject: 'Update on {address}',
    body: `Hi {agent_name},

After careful consideration, we're unable to move forward on {address} at the terms presented.

This was a difficult decision as we were genuinely interested in the property. However, the numbers don't work for our investment criteria at this time.

We appreciate being considered and would welcome the opportunity to work with your team on future properties that may be a better fit.

Please keep us in your database for future opportunities.

Best regards,
GTA 6 Real Estate`
  }
}

// Send email via Gmail API (user's connected Gmail)
async function sendGmailAPI(
  refreshToken: string,
  userEmail: string,
  toEmail: string, 
  subject: string, 
  body: string
): Promise<{ success: boolean; messageId?: string; error?: string }> {
  try {
    // First, refresh the access token
    const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: Deno.env.get('GMAIL_CLIENT_ID') || '',
        client_secret: Deno.env.get('GMAIL_CLIENT_SECRET') || '',
        refresh_token: refreshToken,
        grant_type: 'refresh_token'
      })
    })

    const tokens = await tokenResponse.json()
    const accessToken = tokens.access_token

    if (!accessToken) {
      return { success: false, error: 'Failed to get access token' }
    }

    // Create email
    const emailContent = [
      `From: ${userEmail}`,
      `To: ${toEmail}`,
      `Subject: ${subject}`,
      '',
      body
    ].join('\r\n')

    const encodedEmail = btoa(emailContent)
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '')

    // Send via Gmail API
    const response = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ raw: encodedEmail })
    })

    if (response.ok) {
      const data = await response.json()
      return { success: true, messageId: data.id }
    } else {
      const error = await response.text()
      return { success: false, error }
    }
  } catch (error) {
    return { success: false, error: error.message }
  }
}

// Fallback: Send email via Gmail SMTP (for backward compatibility)
async function sendGmailSMTP(toEmail: string, subject: string, body: string): Promise<{ success: boolean; messageId?: string; error?: string }> {
  try {
    // Create SMTP command
    const smtpCommands = [
      `EHLO localhost\r\n`,
      `AUTH LOGIN\r\n`,
      `${encode(SMTP_USER)}\r\n`,
      `${encode(SMTP_PASS)}\r\n`,
      `MAIL FROM:<${SMTP_USER}>\r\n`,
      `RCPT TO:<${toEmail}>\r\n`,
      `DATA\r\n`,
      `From: GTA 6 Real Estate <${SMTP_USER}>\r\n`,
      `To: ${toEmail}\r\n`,
      `Subject: ${subject}\r\n`,
      `${body}\r\n`,
      `.\r\n`,
      `QUIT\r\n`
    ].join('')

    // Connect and send
    const conn = await Deno.connectTls(SMTP_HOST, SMTP_PORT)
    const encoder = new TextEncoder()
    const decoder = new TextDecoder()
    
    let response = ''
    
    // Send EHLO
    await conn.write(encoder.encode(smtpCommands))
    
    // Read response
    const buffer = new Uint8Array(4096)
    const n = await conn.read(buffer)
    response = decoder.decode(buffer.slice(0, n))
    
    await conn.close()
    
    // Check for success
    if (response.includes('250') || response.includes('OK')) {
      return { success: true, messageId: Date.now().toString() }
    }
    
    return { success: false, error: response }
  } catch (error) {
    return { success: false, error: error.message }
  }
}

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  
  try {
    const { 
      property_id, 
      offer_id, 
      recipient_email, 
      recipient_name, 
      offer_type,
      use_ai,        // Set to true to generate AI email
      custom_message, // Custom instructions for AI
      test_mode,      // Set to true to test without sending
      account_id      // User's account ID
    } = await req.json()
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseKey)

    // Get user's API config
    const userConfig = account_id ? await getUserConfig(supabase, account_id) : null

    // Get property and offer data
    const { data: property } = await supabase.from('properties').select('*').eq('property_id', property_id).single()
    const { data: offer } = await supabase.from('offers').select('*').eq('offer_id', offer_id).single()
    
    if (!property) throw new Error('Property not found')
    
    // Check if AI email generation is requested
    let subject: string
    let body: string
    
    if (use_ai) {
      console.log('🤖 Generating AI email...')
      const aiResult = await generateAIEmail(property, offer, offer_type, userConfig, custom_message || undefined)
      subject = aiResult.subject
      body = aiResult.body
      console.log('🤖 AI email generated:', subject.slice(0, 50))
    } else {
      // Use template
      const template = TEMPLATES[offer_type] || TEMPLATES.initial_offer
      subject = template.subject
      body = template.body
    }
    
    // Replace placeholders (for both AI and template)
    subject = subject
      .replace('{address}', property.address || '')
      .replace('{city}', property.city || '')
      .replace('{offer_price}', `${(offer?.offer_price || property.listing_price || 0).toLocaleString()}`)
      .replace('{estimated_value}', `${(property.estimated_value || 0).toLocaleString()}`)
      .replace('{counter_price}', `${(offer?.counter_price || 0).toLocaleString()}`)
      .replace('{response_price}', `${(offer?.response_price || 0).toLocaleString()}`)
      .replace('{agreed_price}', `${(offer?.agreed_price || offer?.offer_price || 0).toLocaleString()}`)
    
    body = body
      .replace('{address}', property.address || '')
      .replace('{city}', property.city || '')
      .replace('{agent_name}', recipient_name || property.listing_agent_full_name || 'Agent')
      .replace('{offer_price}', `${(offer?.offer_price || property.listing_price || 0).toLocaleString()}`)
      .replace('{estimated_value}', `${(property.estimated_value || 0).toLocaleString()}`)
      .replace('{down_payment}', offer?.down_payment_percent?.toString() || '10')
      .replace('{closing_days}', offer?.closing_days?.toString() || '21')
      .replace('{financing_type}', offer?.financing_type || 'Flexible Financing Available')
      .replace('{counter_price}', `${(offer?.counter_price || 0).toLocaleString()}`)
      .replace('{response_price}', `${(offer?.response_price || 0).toLocaleString()}`)
      .replace('{closing_date}', offer?.closing_date || '21 days')
      .replace('{agreed_price}', `$${(offer?.agreed_price || offer?.offer_price || 0).toLocaleString()}`)

    let emailSent = false
    let messageId = null
    let emailError = null

    // Send real email unless in test mode
    if (!test_mode && recipient_email) {
      let result: { success: boolean; messageId?: string; error?: string }
      
      // Check if user has connected Gmail
      if (userConfig?.gmail_refresh_token && userConfig?.gmail_email) {
        console.log('📧 Using user\'s connected Gmail...')
        result = await sendGmailAPI(
          userConfig.gmail_refresh_token,
          userConfig.gmail_email,
          recipient_email,
          subject,
          body
        )
      } else {
        // Fallback to system Gmail if user hasn't connected
        console.log('📧 Using fallback system Gmail...')
        result = await sendGmailSMTP(recipient_email, subject, body)
      }
      
      emailSent = result.success
      messageId = result.messageId
      emailError = result.error
    } else if (test_mode) {
      console.log('📧 TEST MODE - Email not sent')
    }
    
    // Always log to database
    await supabase.from('communications').insert({ 
      property_id, 
      offer_id,
      comm_type: 'email', 
      direction: 'outbound', 
      to_email: recipient_email, 
      to_name: recipient_name || property.listing_agent_full_name || 'Agent', 
      subject, 
      message: body, 
      category: offer_type, 
      user_id: property.account_id, 
      sentiment: 'neutral',
      message_id: messageId,
      status: emailSent ? 'sent' : (test_mode ? 'test' : 'failed')
    })
    
    // Update offer status
    await supabase.from('offers').update({ 
      status: offer_type === 'acceptance' ? 'accepted' : 'pending_response', 
      sent_at: new Date().toISOString(),
      message_id: messageId
    }).eq('offer_id', offer_id)

    // Schedule follow-ups for initial offer
    if (offer_type === 'initial_offer') {
      const followUpTypes = [
        { days: 3, type: 'follow_up_1' },
        { days: 7, type: 'follow_up_2' },
        { days: 14, type: 'follow_up_3' }
      ]
      
      for (const fu of followUpTypes) {
        const followUpDate = new Date()
        followUpDate.setDate(followUpDate.getDate() + fu.days)
        
        await supabase.from('follow_up_queue').insert({ 
          property_id, 
          offer_id, 
          scheduled_for: followUpDate.toISOString(), 
          follow_up_type: fu.type, 
          status: 'pending' 
        })
      }
    }

    return new Response(JSON.stringify({ 
      success: true, 
      email_sent: emailSent,
      message: emailSent ? 'Email sent successfully!' : (test_mode ? 'Test mode - no email sent' : 'Email failed to send'),
      message_id: messageId,
      subject: subject,
      recipient: recipient_email,
      error: emailError
    }), { 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200 
    })
    
  } catch (error) {
    console.error('Email send error:', error)
    return new Response(JSON.stringify({ 
      success: false, 
      error: error.message 
    }), { 
      status: 500, 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
    })
  }
})
